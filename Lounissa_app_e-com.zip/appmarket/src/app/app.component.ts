import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

   hist_tab = [];
  initialCount: number = 20;
  title = '';

  prod_femme = [{name:"Escarpin rouge   ","src":"assets/img/escarpin.jpg","homme":15,"femme":75,"age_m26":43,"csp_ok": 50,"csp_ko": 33,"age_p50":25,"age_m50":54},]
  products =[{name:"perfum chanel","src":"assets/img/chanelp1.jpg","homme":60,"femme":80,"age_m26":50,"csp_ok": 65,"csp_ko": 35, "age_p50":45,"age_m50":65},
  {name:"Aspirateur sans fil ","src":"assets/img/Aspip2.jpg","homme":30,"femme":80,"age_m26":80,"csp_ok": 45,"csp_ko": 35,"age_p50":40,"age_m50":60},
  {name:"Chocolat","src":"assets/img/chocolatp5.jpg","homme":30,"femme":60,"age_m26":45,"csp_ok": 65,"csp_ko": 85,"age_p50":25,"age_m50":40},
  {name:"Combainison moto","src":"assets/img/combip6.jpeg","homme":90,"femme":20,"age_m26":35,"csp_ok": 40,"csp_ko": 55,"age_p50":25,"age_m50":50},
  {name:"tondeuse élèctrique ","src":"assets/img/tondeuse-electrique.jpg","homme":80,"femme":20,"age_m26":25,"csp_ok": 55,"csp_ko": 50,"age_p50":65,"age_m50":55},
  {name:"x-box","src":"assets/img/x-box.png","homme":70,"femme":30,"age_m26":55,"csp_ok": 65,"csp_ko": 35,"age_p50":15,"age_m50":45},
  {name:"Mac ","src":"assets/img/mac.jpg","homme":40,"femme":60,"age_m26":65,"csp_ok": 65,"csp_ko": 30,"age_p50":45,"age_m50":50},
  {name:"penceaux","src":"assets/img/penceaux-maq.png","homme":20,"femme":80,"age_m26":55,"csp_ok": 40,"csp_ko": 45,"age_p50":35,"age_m50":40},
  {name:"Rasoir ","src":"assets/img/ton-barbe.jpeg","homme":80,"femme":35,"age_m26":45,"csp_ok": 40,"csp_ko": 55,"age_p50":55,"age_m50":45},
  {name:"Fleur  ","src":"assets/img/fleurp4.jpg","homme":50,"femme":40,"age_m26":60,"csp_ok": 50,"csp_ko": 25,"age_p50":65,"age_m50":55},

  {name:"Vase gallé   ","src":"assets/img/vase-gallé.jpg","homme":30,"femme":60,"age_m26":20,"csp_ok": 70,"csp_ko": 25,"age_p50":60,"age_m50":40},

  
  {name:"Meuble TV   ","src":"assets/img/meuble-tv.jpeg","homme":25,"femme":65,"age_m26":33,"csp_ok": 60,"csp_ko": 53,"age_p50":35,"age_m50":55},

  {name:"Produit nettoyant   ","src":"assets/img/mr-propre.jpg","homme":15,"femme":75,"age_m26":45,"csp_ok": 70,"csp_ko": 33,"age_p50":55,"age_m50":85},

  {name:"Cafetière en argent   ","src":"assets/img/caf-argent.jpg","homme":20,"femme":60,"age_m26":25,"csp_ok": 85,"csp_ko": 73,"age_p50":50,"age_m50":60},
  {name:" Papier Imprimante et Copieur","src":"assets/img/feuilles.jpg","homme":50,"femme":40,"age_m26":15,"csp_ok": 40,"csp_ko": 50,"age_p50":54,"age_m50":50},
  {name:" Ram ","src":"assets/img/ram.png","homme":85,"femme":20,"age_m26":55,"csp_ok": 30,"csp_ko": 45,"age_p50":34,"age_m50":45},

  {name:"Piano  ","src":"assets/img/piano.jpg","homme":85,"femme":20,"age_m26":55,"csp_ok": 30,"csp_ko": 45,"age_p50":34,"age_m50":45},

  {name:"Power bank ","src":"assets/img/power-bank.jpeg","homme":70,"femme":75,"age_m26":65,"csp_ok": 45,"csp_ko": 30,"age_p50":35,"age_m50":55},

  {name:"Lots de biberons ","src":"assets/img/biberons.jpg","homme":25,"femme":70,"age_m26":35,"csp_ok":55,"csp_ko": 28,"age_p50":15,"age_m50":45},
  ]

get product_filtered(){

	return this.products
}

public nb_carac_ok(a,b)
{
  let nb_dif =0;
  var tab_dif = [];
  tab_dif[0] = Math.abs(a.homme-b.homme);
  tab_dif[1] = Math.abs(a.femme-b.femme);
  tab_dif[2] = Math.abs(a.age_m26-b.age_m26);
  tab_dif[3] = Math.abs(a.csp_ok-b.csp_ok);
  tab_dif[4] = Math.abs(a.csp_ko-b.csp_ko);
  tab_dif[5] = Math.abs(a.age_p50-b.age_p50);
  tab_dif[6] = Math.abs(a.age_m50-b.age_m50);

for(let cara of tab_dif){
  
  if(cara <= 15)
  {
   // console.log(' la diff ok  ===> produits selectionné  '+cara);
    nb_dif+=1;
  }
}

return nb_dif;


}
public Calcul_Barycentre(tab)
{
  let femme=0;
  let homme =0;
  let nb_pro=0;
  var new_products = [];
  let nb_prod_selec = tab.length;
  //console.log(' le nombre de produits selectionné ===>   '+nb_prod_selec);

	 let  obj_ref= {
    homme: 0,
    femme: 0,
    age_m26:0,
    csp_ok: 0,
    csp_ko: 0,
    age_p50:0,
    age_m50:0

  }
    // calcule des valeurs des attributs pour l'obj référent 
  	for (let entry of tab) {

      obj_ref.homme += Math.trunc(entry.homme/nb_prod_selec);
      obj_ref.femme += Math.trunc(entry.femme/nb_prod_selec);
      obj_ref.age_m26 += Math.trunc(entry.age_m26/nb_prod_selec);
      obj_ref.csp_ok += Math.trunc(entry.csp_ok/nb_prod_selec);
      obj_ref.csp_ko += Math.trunc(entry.csp_ko/nb_prod_selec);

      obj_ref.age_p50 += Math.trunc(entry.age_p50/nb_prod_selec);
      obj_ref.age_m50 += Math.trunc(entry.ge_m50/nb_prod_selec);

    }

console.log(' l objet référent  ===>   '+obj_ref.femme);
    // mise à jour de la page en fonction de mon objet référent : en cherchant le plus proche

    for (let pro of this.products) {
        let r =this.nb_carac_ok (pro,obj_ref);
          //console.log('la diff entre l obj référent et le produit ' +pro.name+'   ===>  '+r);

        if((r >= 3) && (new_products.indexOf(pro.name) == -1))
        {
          new_products.push(pro);
          //nb_pro +=1;
          femme += Math.trunc(pro.femme/new_products.length);
         // console.log('produit empilé    ===>  '+pro.name);
         // console.log('% femme    ===>  '+femme);

        }


    }
    this.products = new_products;

    //console.log('l ensemble de produits qui sont proches à ce que qu a été sélectionné  :: ===>  '+new_products);

    // si le nombre de cara proche à mon obj_ref est = ou plus que 4 je le push dans mon tab_final ===> qui remplacer mon tableau //product ( mise à jour )


}
public DisplayProduct(product){
  //à chaque clique j'appelle cette pour : empiler les produits dans un tableau,
// puis je les file à la fonction qui calcule le bary-centre

// mis à jour ma page en fonction de la liste de produits qu'on été selectionnée ( la sortie de la fonction calculant le bary-centre )
  this.hist_tab.push(product);
  var taille = this.hist_tab.length;

    /*for (let entry of this.hist_tab) {
      console.log('hist - tableau   ');
      console.log(entry);
      console.log('taille = '+taille);
    }*/

return this.Calcul_Barycentre(this.hist_tab);
}


}
