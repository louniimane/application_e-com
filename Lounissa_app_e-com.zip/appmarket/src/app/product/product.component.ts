import { Component, OnInit , Output, Input } from '@angular/core';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  inputs :["product"]
})
export class ProductComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
